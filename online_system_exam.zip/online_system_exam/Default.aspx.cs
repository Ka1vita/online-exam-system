﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page
{
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
    Response.Redirect("hh.aspx");
    }
    string gender;
    protected void Button1_Click(object sender, EventArgs e)

    {

        if (TextBox3.Text == TextBox4.Text)
        {
            Response.Write("password mathched");
        }
        else
        {
            Response.Write("password  do not mathched.plz. write same as above password.");
        }

        
        if (RadioButton1.Checked == true)
        {
            gender = "male";
        }
        else
        {
            gender = "female";
        }


        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");
        SqlCommand cmd = new SqlCommand("insert into reg(name,username,Password,E_mail,Mobile_No,gender,state)values(@name,@username,@Password,@E_mail,@Mobile_No,@gender,@state)", con);
        cmd.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@username", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Password", TextBox3.Text);
        cmd.Parameters.AddWithValue("@E_mail", TextBox4.Text);
        cmd.Parameters.AddWithValue("@Mobile_No",Convert.ToInt64(TextBox6.Text));
        cmd.Parameters.AddWithValue("@gender",gender);
        cmd.Parameters.AddWithValue("@state",DropDownList1.SelectedItem.ToString());

        con.Open();
        int a = cmd.ExecuteNonQuery();
        if (a > 0)
        {

            Response.Write("submit");
            Response.Redirect("login.aspx");
        }
        else
        {
            Response.Write("not submit");
        }

        con.Close();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("hh.aspx");
    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
  
    
    
     
     