﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class about_page : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");
        SqlCommand cmd = new SqlCommand("insert into feedback(name ,E_mail ,comment)values(@name,@e_mail,@comment)", con);
        cmd.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@E_mail", TextBox2.Text);
        cmd.Parameters.AddWithValue("@comment", TextBox3.Text);

        //cmd.Parameters.AddWithValue("@slary", Convert.ToInt32(TextBox3.Text));
        con.Open();


       

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
            {
              //alert create to show msg
                Response.Redirect("submited"); 
            }
            else
            {
                Response.Write("not submit");
            }

        }

        con.Close();

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("hh.aspx"); 
    }
}