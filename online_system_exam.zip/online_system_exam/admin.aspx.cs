﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {//details of all user viewed by admin
        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");//db=exam
        SqlCommand cmd = new SqlCommand("select * from reg", con);  //login=table

        //cmd.Parameters.AddWithValue("@us", TextBox1.Text);
        //cmd.Parameters.AddWithValue("@pass", TextBox2.Text);


        con.Open();

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
            {
                Response.Redirect("grid.aspx");  //redirects to  all user-list page
            }

        }

        con.Close();
    }





    protected void Button2_Click(object sender, EventArgs e)
    {  //result-page
        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");//db=exam
        SqlCommand cmd = new SqlCommand("select *from result ", con);  //result=table

        con.Open();

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
            {
                Response.Redirect("grid3.aspx");  //redirects to   one result-list page
            }

        }

        con.Close();
    }


    protected void Button3_Click(object sender, EventArgs e)
    {
        //details of single user

        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");//db=exam
        SqlCommand cmd = new SqlCommand("select *from login ", con);  //login=table
        //  cmd.Parameters.AddWithValue("@us", TextBox1.Text);


        con.Open();

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
            {
                Response.Redirect("grid1.aspx");  //redirects to single user- list page
            }
        }

        con.Close();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //details of all  feedback  for admin
        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");//db=exam
        SqlCommand cmd = new SqlCommand("select * from feedback", con);  //login=table

        


        con.Open();

        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            if (dr.Read())
            {
                Response.Redirect("grid2.aspx");  //redirects to  all feedback-list page
            }

        }

        con.Close();
    }
}


