﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class admin_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");
        SqlCommand cmd = new SqlCommand("select *from admin where Admin_name=@ad and Password=@pass", con);

        cmd.Parameters.AddWithValue("@ad", TextBox1.Text);
        cmd.Parameters.AddWithValue("@pass", TextBox2.Text);
        
        con.Open();

        SqlDataReader dr=cmd.ExecuteReader();
        if (dr.HasRows)
        {
              if(dr.Read());
            {
               Response.Redirect("admin.aspx");  //redirects to  admin -AREA
            }

        }
        else
        {
            Response.Redirect(" user and password not valid");
        }
        con.Close();

    }
   
}