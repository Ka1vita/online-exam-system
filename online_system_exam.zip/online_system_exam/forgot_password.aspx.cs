﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class forgot_password : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");
        SqlCommand cmd = new SqlCommand("select  password from forgot  where e_mail=@e_mail  and Mobile_No=@Mobile_No", con);
        cmd.Parameters.AddWithValue("@e_mail", (TextBox1.Text));
        cmd.Parameters.AddWithValue("@Mobile_No", Convert.ToInt64(TextBox2.Text));

        con.Open();

        SqlDataReader dr =cmd.ExecuteReader();  //reads the data from select command
        if (dr.HasRows)
        {
            if (dr.Read())
            {  //session
               // Label2.Text = Session["username"].ToString();
                TextBox3.Text = dr["password"].ToString();

            }
        }

        else
        {
            Response.Write("no password.");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
    
}