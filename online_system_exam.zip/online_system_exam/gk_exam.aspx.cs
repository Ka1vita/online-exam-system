﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class gk_exam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["username"].ToString();
    }

        int ob ;

   
    protected void Button1_Click(object sender, EventArgs e)
        {
            //Session["username"] = Label1.Text;  session creates

        ob = Convert.ToInt32(Request.QueryString["value"].ToString());

      if (RadioButton4.Checked==true)//1
        {
              ob=ob+5;
        }
      
        if (RadioButton2.Checked==true)//2
        {
              ob=ob+5;
        }
       

        if (RadioButton4.Checked==true)//3
        {
              ob=ob+5;
        }
       

        if (RadioButton4.Checked==true)//4
        {
              ob=ob+5;
        }
       

        if (RadioButton1.Checked==true)//5
        {
              ob=ob+5;
        }
        


        if (RadioButton4.Checked==true)  //6
        {
              ob=ob+5;
        }
      


        Response.Redirect("start3.aspx?value="+ob);
     }
    
}
    
