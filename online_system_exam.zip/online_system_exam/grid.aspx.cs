﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class grid : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
         //full database  checked by admin
        SqlDataAdapter da = new SqlDataAdapter("select *from login ", "Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security= True");
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind(); 

   
      
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}