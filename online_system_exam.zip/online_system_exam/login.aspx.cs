﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
   
    protected void Button1_Click(object sender, EventArgs e)
    {   
        SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");//db=exam
        SqlCommand cmd = new SqlCommand("select *from login where User_name=@us and Password=@pass",con);  //login=table
        
        cmd.Parameters.AddWithValue("@us", TextBox1.Text);
        cmd.Parameters.AddWithValue("@pass", TextBox2.Text);
        
        
        con.Open();

        SqlDataReader dr= cmd.ExecuteReader();
        
        if (dr.HasRows)
        {
              if(dr.Read())
            {
                Session["username"] = TextBox1.Text;  //session creates
                Session["password"] = TextBox2.Text;
                          Response.Redirect("list.aspx");  //redirects to  list page
            }

        }
        else
        {
            Response.Redirect(" user and password not valid");
        }
        con.Close();
    }

   
}
