﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class rsn_exam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
         Label2.Text = Session["username"].ToString();
    }
        
        
        int ob;




        string result;
        int total_marks;
 protected void Button1_Click1(object sender, EventArgs e)
  {

      ob = Convert.ToInt32(Request.QueryString["value"].ToString());

      if (RadioButton1.Checked == true)//1
      {
          ob = ob + 5;
      }
   

      if (RadioButton4.Checked == true)//2
      {
          ob = ob + 5;
      }
     

      if (RadioButton2.Checked == true)//3
      {
          ob = ob + 5;
      }
     

      if (RadioButton3.Checked == true)//4
      {
          ob = ob + 5;
      }
       

      if (RadioButton4.Checked == true)//5
      {
          ob = ob + 5;
      }
     


      if (RadioButton2.Checked == true)  //6
      {
          ob = ob + 5;
      }
      if (ob > 50)
      {

          result = "PASS";
      }
      else
      {
          result = "FAIL";
      }

      total_marks = 120;
      SqlConnection con = new SqlConnection("Data Source=SHRIKRISHNA;Initial Catalog=exam; Integrated Security=True");//db=exam
      SqlCommand cmd = new SqlCommand("insert into result(User_name,password,total_marks,obtained_marks,result)values(@us,@pass,@tm,@om,@result)",con);  //login=table
      cmd.Parameters.AddWithValue("@us", Session["username"].ToString());
      cmd.Parameters.AddWithValue("@pass", Session["password"].ToString());
      cmd.Parameters.AddWithValue("@tm",total_marks);
      cmd.Parameters.AddWithValue("@om",ob);
      cmd.Parameters.AddWithValue("@result",result);
      

      con.Open();
      int a = cmd.ExecuteNonQuery();
      con.Close();
      Response.Redirect("result.aspx");

  }
}
