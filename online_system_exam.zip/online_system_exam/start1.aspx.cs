﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class start1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["username"].ToString();
        /*Label2.Text = Session["username"].ToString();  //session creates
        string s;
        s = Request.QueryString["value"];
        ob= Convert.ToInt32(s);
        Response.Write("the value is "  +ob);*/
    }
    int ob;
    protected void Button1_Click(object sender, EventArgs e)
    {

      // Session["username"] = Label2.Text;

        Response.Redirect("cs_exam.aspx");
    }
}