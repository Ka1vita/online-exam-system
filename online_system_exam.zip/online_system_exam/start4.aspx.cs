﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class start4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["username"].ToString();
    }
    int ob;
    protected void Button1_Click(object sender, EventArgs e)
    {
       // Session["username"] = Label2.Text;  session creates
        ob = Convert.ToInt32(Request.QueryString["value"].ToString());


        Response.Redirect("rsn_exam.aspx?value="+ob);
    }
}